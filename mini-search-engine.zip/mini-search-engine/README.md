# Mini Search Engine (Trie + Inverted Index + TF‑IDF)

**Goal:** A SWE/DSA project that implements core data structures and algorithms:
- **Trie** for autocomplete
- **Inverted Index** with **TF‑IDF** weights
- **Cosine similarity** ranking over a small corpus

## Features
- Ingest a folder of `.txt` documents
- Tokenize, lowercase, strip punctuation, remove stopwords
- Build Trie for autocomplete and Inverted Index for search
- Rank search results using TF‑IDF and cosine similarity
- Simple CLI to query: autocomplete terms and search documents

## Build & Run
```bash
# Requirements: Java 17+, Maven
mvn -v

# Build
mvn clean package

# Run (loads sample docs in ./data/docs)
java -jar target/mini-search-engine-1.0.0-jar-with-dependencies.jar data/docs
```

At the prompt:
- Type: `auto <prefix>` for term suggestions (e.g., `auto he`)
- Type: `search <query terms>` (e.g., `search heart disease`)
- Type: `exit` to quit

## Project Structure
- `Tokenizer.java` – tokenization & stopword filtering
- `Trie.java` – classic prefix tree with insert & suggest
- `InvertedIndex.java` – postings with term frequencies and DF counts
- `Ranker.java` – TF‑IDF vectorization + cosine similarity
- `SearchEngine.java` – CLI + wiring
- `data/docs` – sample corpus

## Why this is SWE‑ready
- Clean object‑oriented design and packages
- Deterministic algorithms with tests
- CLI and runnable jar via Maven Assembly Plugin

## Next Steps
- Add wildcard queries
- Persist index to disk (serialization)
- Add basic HTTP server (Spark/FastAPI equivalent in Java)
